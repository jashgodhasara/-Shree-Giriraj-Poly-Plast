@echo off
setlocal enabledelayedexpansion
title Shree Giriraj ERP - Offline Local Mode
echo Starting Offline ERP on Local PC...

set PHP_BIN=php
if exist "C:\xampp\php\php.exe" set PHP_BIN=C:\xampp\php\php.exe

set LARAVEL_DIR=
if exist "%~dp0laravel\artisan" set LARAVEL_DIR=%~dp0laravel
if not defined LARAVEL_DIR if exist "%~dp0..\laravel\artisan" set LARAVEL_DIR=%~dp0..\laravel
if not defined LARAVEL_DIR if exist "C:\xampp\htdocs\shreegiriraj\laravel\artisan" set LARAVEL_DIR=C:\xampp\htdocs\shreegiriraj\laravel

curl -s -m 2 http://127.0.0.1:8000/login >nul 2>&1
if %ERRORLEVEL% NEQ 0 (
    if defined LARAVEL_DIR (
        pushd "%LARAVEL_DIR%"
        start "Shree Giriraj ERP Local" /min "%PHP_BIN%" artisan serve --host=127.0.0.1 --port=8000
        popd
        timeout /t 2 /nobreak >nul
    )
)

if exist "%ProgramFiles(x86)%\Microsoft\Edge\Application\msedge.exe" (
    start "" "%ProgramFiles(x86)%\Microsoft\Edge\Application\msedge.exe" --app="http://127.0.0.1:8000" --window-size=1366,820
    exit /b
)
if exist "%ProgramFiles%\Microsoft\Edge\Application\msedge.exe" (
    start "" "%ProgramFiles%\Microsoft\Edge\Application\msedge.exe" --app="http://127.0.0.1:8000" --window-size=1366,820
    exit /b
)
if exist "%ProgramFiles%\Google\Chrome\Application\chrome.exe" (
    start "" "%ProgramFiles%\Google\Chrome\Application\chrome.exe" --app="http://127.0.0.1:8000" --window-size=1366,820
    exit /b
)
start http://127.0.0.1:8000
exit /b
