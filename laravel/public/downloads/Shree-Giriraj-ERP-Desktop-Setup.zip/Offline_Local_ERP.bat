@echo off
title Shree Giriraj ERP - Offline Local Mode
echo Starting Offline ERP on Local PC...
set PHP_BIN=php
if exist "C:\xampp\php\php.exe" set PHP_BIN=C:\xampp\php\php.exe
if exist "%~dp0..\laravel" (
    cd /d "%~dp0..\laravel"
    start "Shree Giriraj ERP Local" /min "%PHP_BIN%" artisan serve --host=127.0.0.1 --port=8000
    timeout /t 2 /nobreak >nul
)
if exist "%ProgramFiles(x86)%\Microsoft\Edge\Application\msedge.exe" (
    start "" "%ProgramFiles(x86)%\Microsoft\Edge\Application\msedge.exe" --app="http://127.0.0.1:8000" --window-size=1366,820
    exit /b
)
start http://127.0.0.1:8000
exit /b
