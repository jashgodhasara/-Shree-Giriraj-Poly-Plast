@echo off
title Shree Giriraj Poly Plast ERP - Desktop App
echo ===================================================================
echo   SHREE GIRIRAJ POLY PLAST ERP - WINDOWS DESKTOP APPLICATION
echo ===================================================================
echo.
echo Launching ERP Native Window...

set TARGET_URL=https://shreegiriraj-erp.onrender.com

:: 1. Microsoft Edge App Mode (Built-in on Windows 10/11)
if exist "%ProgramFiles(x86)%\Microsoft\Edge\Application\msedge.exe" (
    start "" "%ProgramFiles(x86)%\Microsoft\Edge\Application\msedge.exe" --app="%TARGET_URL%" --window-size=1366,820
    exit /b
)
if exist "%ProgramFiles%\Microsoft\Edge\Application\msedge.exe" (
    start "" "%ProgramFiles%\Microsoft\Edge\Application\msedge.exe" --app="%TARGET_URL%" --window-size=1366,820
    exit /b
)

:: 2. Google Chrome App Mode
if exist "%ProgramFiles%\Google\Chrome\Application\chrome.exe" (
    start "" "%ProgramFiles%\Google\Chrome\Application\chrome.exe" --app="%TARGET_URL%" --window-size=1366,820
    exit /b
)
if exist "%ProgramFiles(x86)%\Google\Chrome\Application\chrome.exe" (
    start "" "%ProgramFiles(x86)%\Google\Chrome\Application\chrome.exe" --app="%TARGET_URL%" --window-size=1366,820
    exit /b
)
if exist "%LocalAppData%\Google\Chrome\Application\chrome.exe" (
    start "" "%LocalAppData%\Google\Chrome\Application\chrome.exe" --app="%TARGET_URL%" --window-size=1366,820
    exit /b
)

:: 3. Default browser fallback
start %TARGET_URL%
exit /b
