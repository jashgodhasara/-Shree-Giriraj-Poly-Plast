@echo off
setlocal
title Shree Giriraj Poly Plast ERP
echo ===================================================================
echo   SHREE GIRIRAJ POLY PLAST ERP - HYBRID DESKTOP APPLICATION
echo ===================================================================
echo.
echo [1/2] Checking Network and Server Status...

set ONLINE_URL=https://shreegiriraj-erp.onrender.com
set OFFLINE_URL=http://127.0.0.1:8000
set TARGET_URL=%ONLINE_URL%

:: Test if online cloud is reachable
curl -s -m 3 %ONLINE_URL%/api >nul 2>&1
if %ERRORLEVEL% NEQ 0 (
    echo [Notice] Working in Offline Mode (No Internet).
    echo Starting Local ERP Database Engine...
    
    :: Find PHP executable
    set PHP_BIN=php
    if exist "C:\xampp\php\php.exe" set PHP_BIN=C:\xampp\php\php.exe

    :: Check if local backend is already running
    curl -s -m 2 %OFFLINE_URL%/login >nul 2>&1
    if %ERRORLEVEL% NEQ 0 (
        if exist "%~dp0..\laravel" (
            cd /d "%~dp0..\laravel"
            start "Shree Giriraj ERP Local Backend" /min "%PHP_BIN%" artisan serve --host=127.0.0.1 --port=8000
            timeout /t 2 /nobreak >nul
        )
    )
    set TARGET_URL=%OFFLINE_URL%
) else (
    echo [Status] Connected to Live Cloud ERP!
)

echo [2/2] Opening Native Window...

:: 1. Microsoft Edge App Mode (Windows 10 / 11)
if exist "%ProgramFiles(x86)%\Microsoft\Edge\Application\msedge.exe" (
    start "" "%ProgramFiles(x86)%\Microsoft\Edge\Application\msedge.exe" --app="%TARGET_URL%" --window-size=1366,820
    exit /b
)
if exist "%ProgramFiles%\Microsoft\Edge\Application\msedge.exe" (
    start "" "%ProgramFiles%\Microsoft\Edge\Application\msedge.exe" --app="%TARGET_URL%" --window-size=1366,820
    exit /b
)

:: 2. Google Chrome App Mode
if exist "%ProgramFiles%\Google\Chrome\Application\chrome.exe" (
    start "" "%ProgramFiles%\Google\Chrome\Application\chrome.exe" --app="%TARGET_URL%" --window-size=1366,820
    exit /b
)
if exist "%ProgramFiles(x86)%\Google\Chrome\Application\chrome.exe" (
    start "" "%ProgramFiles(x86)%\Google\Chrome\Application\chrome.exe" --app="%TARGET_URL%" --window-size=1366,820
    exit /b
)
if exist "%LocalAppData%\Google\Chrome\Application\chrome.exe" (
    start "" "%LocalAppData%\Google\Chrome\Application\chrome.exe" --app="%TARGET_URL%" --window-size=1366,820
    exit /b
)

:: 3. Default browser fallback
start %TARGET_URL%
exit /b
