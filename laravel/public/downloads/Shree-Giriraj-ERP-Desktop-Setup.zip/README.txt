===================================================================
  SHREE GIRIRAJ POLY PLAST ERP - DUAL MODE DESKTOP APPLICATION
===================================================================

FEATURES:
1. Works 100% OFFLINE without any internet connection.
2. Auto-Syncs all offline bills & payments to Render Cloud when online.
3. Dedicated desktop app window with thermal invoice printing.

HOW TO RUN:
- Double-click "Launch_Shree_Giriraj_ERP.bat" for auto Smart Mode.
- Double-click "Install_Desktop_Shortcut.bat" to add desktop icon.
- Double-click "Offline_Local_ERP.bat" for direct offline access.
