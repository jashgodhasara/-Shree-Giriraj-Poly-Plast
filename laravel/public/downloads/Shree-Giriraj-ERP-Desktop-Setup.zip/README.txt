===================================================================
  SHREE GIRIRAJ POLY PLAST ERP - WINDOWS DESKTOP SETUP
===================================================================

INSTALLATION & USAGE:
1. Double-click "Launch_Shree_Giriraj_ERP.bat" to start the Desktop Application.
2. Double-click "Install_Desktop_Shortcut.bat" to place a 1-click icon on your Windows Desktop.

FEATURES:
- Opens in dedicated native desktop window without browser bars.
- Instant access to Live Cloud ERP database.
- Thermal invoice printing and hardware accelerated UI.
- Compatible with Windows 10 and Windows 11 (64-bit / 32-bit).
