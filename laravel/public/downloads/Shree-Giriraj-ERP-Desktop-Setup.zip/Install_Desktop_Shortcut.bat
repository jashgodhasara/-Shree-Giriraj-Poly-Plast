@echo off
title Install Shree Giriraj ERP Desktop Shortcut
echo Creating Desktop Shortcut...
powershell -NoProfile -Command "$ws = New-Object -ComObject WScript.Shell; $desktopPath = [Environment]::GetFolderPath('Desktop'); $shortcut = $ws.CreateShortcut([System.IO.Path]::Combine($desktopPath, 'Shree Giriraj Poly Plast ERP.lnk')); $shortcut.TargetPath = [System.IO.Path]::Combine('%~dp0', 'Launch_Shree_Giriraj_ERP.bat'); $shortcut.WorkingDirectory = '%~dp0'; $shortcut.Description = 'Shree Giriraj Poly Plast ERP Desktop Application'; $shortcut.Save(); Write-Host 'Desktop Shortcut Created Successfully!' -ForegroundColor Green"
echo.
echo Shortcut created on your Windows Desktop!
timeout /t 3
